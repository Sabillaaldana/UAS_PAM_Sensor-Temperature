package com.kikik.nagivationdraw.ui.sensor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.kikik.nagivationdraw.R;
import com.kikik.nagivationdraw.databinding.FragmentSensorBinding;
import com.kikik.nagivationdraw.ui.KonversiSuhu;

public class SensorFragment extends Fragment {

    Activity context;

    private FragmentSensorBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        context = getActivity();

        binding = FragmentSensorBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        return root;
    }

    public void onStart(){
        super.onStart();
        Button btn = (Button) context.findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, KonversiSuhu.class);
                startActivity(intent);
            }
        });

    }
}